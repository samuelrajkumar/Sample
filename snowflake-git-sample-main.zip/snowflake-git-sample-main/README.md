# Snowflake Git Sample

A simple repo with a few files that could be used with Snowflake Git Integration.