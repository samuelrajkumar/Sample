EXECUTE IMMEDIATE FROM './tables/simple_table.sql';
EXECUTE IMMEDIATE FROM './procedures/simple_procedure.sql';
EXECUTE IMMEDIATE FROM './tasks/simple_task.sql';